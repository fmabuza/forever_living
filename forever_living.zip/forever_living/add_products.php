<!DOCTYPE html>
<?php 
require_once('db_connection.php');

 

 // starting the session
 //session_start();


var_dump($_GET);


if(!empty($_REQUEST['insert_products']))
{
    
session_start();
    
foreach ($_GET as $key => $value) 
{

    echo $key;
    echo "<br />".$value;
    $_SESSION[$key] = $value;
}
    
    
   
    $db = MyOpenDB();

$query = "INSERT INTO products
        SET 
            product_name = ,
            product_desc = ,
            product_price = ,
            file_directory = 
            ";

    
    
    
        //$result = $db->query($query);
        //if(!$result){echo "Error With Query".mysql_error();}
        
    

}
?>



<html>
    <head>
        <meta charset="utf-8">
        <title>Felicia Mabuza | Writer</title>
        <link rel="stylesheet" href="css/normalize.css">
        <link href='http://fonts.googleapis.com/css?family=Monofett|EB+Garamond|Open+Sans|Open+Sans+Condensed:300|Cedarville+Cursive' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="css/my-style.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <link href="css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
    </head>
    <body>
 
    <!--    
        <header>
            <a href="index.html" id="logo">
            <div class="navbar navbar-inverse navbar-fixed-top">
                <div class="container">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>                                
             </button>
                  <a class="navbar-brand text-muted" href="#">Forever Living</a>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                              <li><a href="index.html">Home</a></li>
                              <li><a href="contact.html">Contact</a></li>
                              <li><a href="products.html">Products</a></li>
                              <li class="active"><a href="join.html" class="selected">Join</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>  
      
                -->
                
<form role="form" action="?insert_products=true" method="get" style="position:absolute; top:125px; left:550px; width: 200px;" >
    <div class="form-group">
      <label for="product">Product Name:</label>
      <input type="text" class="form-control" id="product" placeholder="Enter Product Name">
    </div>
    <div class=".form-group" >
      <label for="description">Description:</label>
      <textarea type="text" class="form-control" id="description" placeholder="Enter Description">
      </textarea>
    </div>
      <div class=".form-group">
      <label for="price">Price:</label>
      <input type="text" class="form-control" id="price" placeholder="0.00">
    </div>   
    <div>
     <br />
      <input type="submit" id="submit">
    </div>   
</form>            

                
            
        </body>       