<?php
function MyOpenDB()
{
$db = mysqli_connect('localhost', 'root', '', 'forever_living');
    if($db == false)
    {
        echo "Connection not working";
     die;   
    }

    return $db;
}
?>