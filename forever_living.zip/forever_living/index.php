<?php
ini_set('display_errors', 'on');
require_once('db_connection.php');
//require_once('db_connection.php');
?>
<!DOCTYPE html>

<html lang="eng">

<head>
    <meta charset="UTF-8">
    <title>PHP Data Objects</title>
    <link rel="stylesheet" href="style.css">
</head>

    <body id="products">
        <h1>Forever Living Products</h1>
    
        <h2>Purchase products by price</h2>
       <!-- <ol>
            <li><i class="lens"></li>Product One</li>
            <li><i class="lens"></li>Product Two</li>
            <li><i class="lens"></li>Product Three</li>
            <li><i class="lens"></li>Product Four</li>
            <li><i class="lens"></li>Product Five</li>
            <li><i class="lens"></li>Product Six</li>
        </ol> -->

<?php 

//Open Databse Connection Inside Schema Forever_living

$db = MyOpenDB();
$query = "SELECT 
                product_name,
                product_desc,
                product_price
            FROM forever_living.products
            ";

        $result = $db->query($query);
        if(!$result){echo "Error With Query".mysql_error();}
        
    
echo "<ol>";
   while($row = $result->fetch_assoc())
   {
       echo '<li>'.$row['product_name'].' -- '.$row['product_desc'].'</li>';   
    }
echo "</ol>";

?>
    </body>



</html>